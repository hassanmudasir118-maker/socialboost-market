import React, { useState, useEffect } from "react";
import {
  Plus, ChevronLeft, CreditCard, Percent, CheckCircle2, XCircle,
  AlertCircle, Flag, Eye, MessageSquare, Star, Wallet as WalletIcon, TrendingUp, Handshake,
  Send, Ban, Trash2, Info,
} from "lucide-react";
import { api } from "./api";
import { PLATFORM_ICONS, PLATFORM_LABELS, PLATFORM_COLORS, StatusBadge, fmt, fmtDate, initials } from "./shared";

// Simple goals. (Old campaigns may use other types; those are kept as they are.)
const GOALS = [
  { key: "video_promotion", label: "Promote my video", hint: "Get more views, likes and shares on one video", linkLabel: "Link to your video" },
  { key: "profile_promotion", label: "Promote my profile or page", hint: "Get more followers on your channel, page or profile", linkLabel: "Link to your profile or page" },
];
const CATEGORIES = ["Tech", "Beauty", "Fitness", "Lifestyle", "Finance", "Travel", "Gaming", "Comedy", "Fashion", "Food", "Outdoor", "Other"];

const dayString = (offsetDays) => {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  return d.toISOString().slice(0, 10);
};

function CampaignForm({ existing, onCancel, onSaved }) {
  const [form, setForm] = useState({
    title: existing?.title || "", platform: existing?.platform || "YOUTUBE",
    accountName: existing?.accountName || "", contentUrl: existing?.contentUrl || "",
    category: existing?.category || "Other", campaignType: existing?.campaignType || "video_promotion",
    requirements: existing?.requirements || "", eligibilityRequirements: existing?.eligibilityRequirements || "",
    targetCountry: existing?.targetCountry || "",
    budgetPerCreator: existing?.budgetPerCreator || "", maxCreators: existing?.maxCreators || 1,
    startDate: existing?.startDate ? existing.startDate.slice(0, 10) : dayString(0),
    endDate: existing?.endDate ? existing.endDate.slice(0, 10) : dayString(14),
  });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const goal = GOALS.find((g) => g.key === form.campaignType);
  const perCreator = Number(form.budgetPerCreator) || 0;
  const creators = Number(form.maxCreators) || 0;
  const total = perCreator * creators;

  const buildPayload = () => {
    const name = form.accountName.trim();
    return {
      title: form.title.trim() || `${goal ? goal.label : "Promotion"}${name ? `: ${name}` : ""}`,
      // The old "description" box is gone: the creator instructions double as the description.
      description: existing?.description || form.requirements.trim(),
      platform: form.platform, contentUrl: form.contentUrl.trim(), accountName: name,
      category: form.category, campaignType: form.campaignType, requirements: form.requirements.trim(),
      eligibilityRequirements: form.eligibilityRequirements.trim() || null,
      requirementsList: existing?.requirementsList || [],
      targetCountry: form.targetCountry.trim() || null,
      budget: total, budgetPerCreator: perCreator, maxCreators: creators,
      startDate: new Date(form.startDate).toISOString(), endDate: new Date(form.endDate).toISOString(),
    };
  };

  const validate = () => {
    if (!form.accountName.trim()) return "Please type the name of your channel or page.";
    if (!/^https?:\/\/\S+$/i.test(form.contentUrl.trim())) return "Please paste the full link. It must start with https://";
    if (form.requirements.trim().length < 10) return "Please tell creators what to do (at least a few words).";
    if (perCreator <= 0) return "Please enter how much you will pay each creator.";
    if (!Number.isInteger(creators) || creators < 1) return "Please enter how many creators you need (1 or more).";
    if (!form.startDate || !form.endDate) return "Please choose the start date and the last date.";
    if (new Date(form.endDate) <= new Date(form.startDate)) return "The last date must be after the start date.";
    return "";
  };

  const submit = async (doSubmit) => {
    const problem = validate();
    if (problem) { setError(problem); return; }
    setError("");
    setBusy(true);
    try {
      if (existing) await api.updateCampaign(existing.id, { ...buildPayload(), submit: doSubmit });
      else await api.createCampaign({ ...buildPayload(), submit: doSubmit });
      onSaved();
    } catch (err) {
      setError(err.message || "Could not save. Please check the form and try again.");
    }
    setBusy(false);
  };

  return (
    <div>
      <button className="back-link" onClick={onCancel}><ChevronLeft size={15} /> Back to campaigns</button>
      <div className="wizard-card">
        <div className="wizard-title">{existing ? "Edit campaign" : "New campaign"}</div>
        <p className="wizard-hint">Fill this form, then pay. After we confirm your payment, press Publish and creators can see your campaign.</p>
        {error && <div className="auth-error">{error}</div>}

        <div className="field">
          <label>1. What do you want?</label>
          <div className="platform-grid">
            {GOALS.map((g) => (
              <button type="button" key={g.key} className={`platform-opt ${form.campaignType === g.key ? "active" : ""}`} onClick={() => setForm({ ...form, campaignType: g.key })}>
                <span style={{ fontWeight: 600 }}>{g.label}</span>
                <span style={{ fontSize: 12, opacity: 0.75, fontWeight: 400 }}>{g.hint}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="field">
          <label>2. Which app?</label>
          <div className="platform-grid">
            {Object.entries(PLATFORM_ICONS).filter(([k]) => k !== "OTHER").map(([key, Icon]) => (
              <button type="button" key={key} className={`platform-opt ${form.platform === key ? "active" : ""}`} onClick={() => setForm({ ...form, platform: key })}>
                <Icon size={20} style={{ color: form.platform === key ? PLATFORM_COLORS[key] : "currentColor" }} />
                {PLATFORM_LABELS[key]}
              </button>
            ))}
          </div>
        </div>

        <div className="field">
          <label>3. Name of your channel, page or profile</label>
          <input type="text" placeholder="e.g. Ali Tech Tips" value={form.accountName} onChange={set("accountName")} />
        </div>
        <div className="field">
          <label>4. {goal ? goal.linkLabel : "Link"}</label>
          <input type="text" inputMode="url" placeholder="https://..." value={form.contentUrl} onChange={set("contentUrl")} />
          <div className="field-hint">Open your video or profile, copy the link from the address bar, and paste it here.</div>
        </div>

        <div className="field">
          <label>5. What should the creator do?</label>
          <textarea placeholder="e.g. Watch my video, like it, and share it with your followers." value={form.requirements} onChange={set("requirements")} />
        </div>

        <div className="field-row">
          <div className="field"><label>6. Pay each creator (Rs)</label><input type="number" min="1" value={form.budgetPerCreator} onChange={set("budgetPerCreator")} /></div>
          <div className="field"><label>How many creators?</label><input type="number" min="1" value={form.maxCreators} onChange={set("maxCreators")} /></div>
        </div>
        {total > 0 && <div className="field-hint" style={{ marginBottom: 14 }}>Total you will pay: <strong>{fmt(total)}</strong> ({fmt(perCreator)} × {creators})</div>}

        <div className="field-row">
          <div className="field"><label>7. Start date</label><input type="date" value={form.startDate} onChange={set("startDate")} /></div>
          <div className="field"><label>Last date</label><input type="date" value={form.endDate} onChange={set("endDate")} /></div>
        </div>

        <details style={{ marginBottom: 16 }}>
          <summary style={{ cursor: "pointer", fontSize: 13.5, fontWeight: 600 }}>More options (not needed)</summary>
          <div style={{ marginTop: 12 }}>
            <div className="field"><label>Campaign name</label><input type="text" placeholder="We will choose a name for you if you leave this empty" value={form.title} onChange={set("title")} /></div>
            <div className="field">
              <label>Topic</label>
              <select value={form.category} onChange={set("category")}>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select>
            </div>
            <div className="field"><label>Creator must live in (country)</label><input type="text" placeholder="e.g. Pakistan" value={form.targetCountry} onChange={set("targetCountry")} /></div>
            <div className="field"><label>Anything creators must have</label><textarea placeholder="e.g. At least 10,000 followers" value={form.eligibilityRequirements} onChange={set("eligibilityRequirements")} /></div>
          </div>
        </details>

        <div className="wizard-nav">
          <button className="btn btn-ghost" onClick={onCancel}>Cancel</button>
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
            <button className="btn btn-ghost" disabled={busy} onClick={() => submit(false)}>Save for later</button>
            <button className="btn btn-primary" disabled={busy} onClick={() => submit(true)}>Continue to payment</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function PaymentBox({ campaign, onFunded }) {
  const [promo, setPromo] = useState("");
  const [showPromo, setShowPromo] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [payment, setPayment] = useState(null);
  const [manualMethods, setManualMethods] = useState([]);
  const [manualAccount, setManualAccount] = useState(null);
  const [reference, setReference] = useState("");
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => { api.manualMethods().then((r) => setManualMethods(r.methods)).catch(() => {}); }, []);

  const startCheckout = async () => {
    setBusy(true); setError("");
    try {
      const result = await api.checkout(campaign.id, promo.trim() || null);
      setPayment(result.payment);
    } catch (err) { setError(err.message || "Failed to start checkout"); }
    setBusy(false);
  };

  const startManualCheckout = async (method) => {
    setBusy(true); setError("");
    try {
      const result = await api.manualCheckout(campaign.id, method);
      setPayment(result.payment);
      setManualAccount(result.account);
    } catch (err) { setError(err.message || "Failed to start payment"); }
    setBusy(false);
  };

  const confirm = async (outcome) => {
    setBusy(true); setError("");
    try {
      await api.simulatePayment(payment.id, outcome);
      onFunded();
    } catch (err) { setError(err.message || "Payment confirmation failed"); }
    setBusy(false);
  };

  const submitReference = async () => {
    if (!reference.trim()) { setError("Enter the transaction reference/ID shown after you send the payment"); return; }
    setBusy(true); setError("");
    try {
      await api.submitManualProof(payment.id, reference.trim());
      setSubmitted(true);
    } catch (err) { setError(err.message || "Failed to submit reference"); }
    setBusy(false);
  };

  // Manual method (EasyPaisa/JazzCash/Bank Transfer) in progress: show the
  // platform's receiving account and a place to submit the reference.
  if (payment && manualAccount) {
    if (submitted) {
      return (
        <div className="payment-box" style={{ flexDirection: "column", alignItems: "stretch" }}>
          <div className="msg">
            <CreditCard size={20} style={{ color: "var(--gold)" }} />
            <div>
              <div style={{ fontWeight: 600, fontSize: 14.5 }}>Payment reference submitted</div>
              <p style={{ fontSize: 13 }}>An admin will verify your {manualAccount.label} payment and fund your campaign once confirmed. This usually doesn't take long — check back soon.</p>
            </div>
          </div>
        </div>
      );
    }
    return (
      <div className="payment-box" style={{ flexDirection: "column", alignItems: "stretch" }}>
        <div className="msg">
          <CreditCard size={20} style={{ color: "var(--gold)" }} />
          <div>
            <div style={{ fontWeight: 600, fontSize: 14.5 }}>Send {fmt(payment.amount)} via {manualAccount.label}</div>
            <p style={{ fontSize: 13 }}>
              Send the payment yourself from your {manualAccount.label} app to:<br />
              <strong>{manualAccount.accountName}</strong> — <strong>{manualAccount.accountNumber}</strong>
              {manualAccount.bankName ? <> ({manualAccount.bankName})</> : null}
            </p>
            <p style={{ fontSize: 13 }}>After sending, enter the transaction ID/reference number shown in your {manualAccount.label} app below, so an admin can confirm it and fund your campaign.</p>
          </div>
        </div>
        <div className="field" style={{ marginTop: 14, marginBottom: 0, maxWidth: 320 }}>
          <label>Transaction reference / ID</label>
          <input type="text" value={reference} onChange={(e) => setReference(e.target.value)} placeholder="e.g. 123456789" />
        </div>
        <div style={{ display: "flex", gap: 10, marginTop: 14 }}>
          <button className="btn btn-primary btn-sm" onClick={submitReference} disabled={busy}>{busy ? "Submitting…" : "I've sent the payment — submit reference"}</button>
        </div>
        {error && <div className="auth-error" style={{ marginTop: 12 }}>{error}</div>}
      </div>
    );
  }

  if (payment) {
    return (
      <div className="payment-box" style={{ flexDirection: "column", alignItems: "stretch" }}>
        <div className="msg">
          <CreditCard size={20} style={{ color: "var(--gold)" }} />
          <div>
            <div style={{ fontWeight: 600, fontSize: 14.5 }}>Complete your payment</div>
            <p style={{ fontSize: 13 }}>{fmt(payment.amount)} · Test mode — no real card form is connected yet. Simulate the provider's response below.</p>
          </div>
        </div>
        <div style={{ display: "flex", gap: 10, marginTop: 14 }}>
          <button className="btn btn-primary btn-sm" onClick={() => confirm("succeeded")} disabled={busy}>Simulate successful payment</button>
          <button className="btn btn-ghost btn-sm" onClick={() => confirm("failed")} disabled={busy}>Simulate declined card</button>
        </div>
        {error && <div className="auth-error" style={{ marginTop: 12 }}>{error}</div>}
      </div>
    );
  }

  return (
    <div className="payment-box" style={{ flexDirection: "column", alignItems: "stretch" }}>
      <div style={{ display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 14, width: "100%" }}>
        <div className="msg">
          <CreditCard size={20} style={{ color: "var(--gold)" }} />
          <div>
            <div style={{ fontWeight: 600, fontSize: 14.5 }}>Payment required</div>
            <p style={{ fontSize: 13 }}>Fund your budget of {fmt(campaign.budget)} via the payment provider.</p>
          </div>
        </div>
        <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
          <button className="btn btn-ghost btn-sm" onClick={() => setShowPromo(!showPromo)}><Percent size={14} /> Promo code</button>
          <button className="btn btn-primary btn-sm" onClick={startCheckout} disabled={busy}><CreditCard size={14} /> {busy ? "Starting…" : "Proceed to checkout"}</button>
          {manualMethods.map((m) => (
            <button key={m.method} className="btn btn-ghost btn-sm" onClick={() => startManualCheckout(m.method)} disabled={busy}>
              Pay via {m.label}
            </button>
          ))}
        </div>
      </div>
      {showPromo && <div className="field" style={{ marginTop: 14, marginBottom: 0, maxWidth: 280 }}><label>Promo code</label><input type="text" value={promo} onChange={(e) => setPromo(e.target.value)} /></div>}
      {error && <div className="auth-error" style={{ marginTop: 12 }}>{error}</div>}
    </div>
  );
}

// Plain-words "what do I do now" for each stage, so advertisers are never stuck.
const NEXT_STEP = {
  DRAFT: "Your campaign is saved but not sent yet. Press Edit, then Continue to payment.",
  PENDING_PAYMENT: "Pay using EasyPaisa below and send us the transaction ID. We check it and confirm your payment.",
  FUNDED: "Your payment is confirmed. Press the Publish button below. Creators cannot see your campaign until you publish it.",
  PUBLISHED: "Your campaign is live. Creators can see it and apply. Check the Applications tab and accept the creators you like.",
};

function PublishBox({ campaign, onPublished }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const publish = async () => {
    setBusy(true); setError("");
    try { const r = await api.publishCampaign(campaign.id); onPublished(r.campaign); }
    catch (err) { setError(err.message || "Failed to publish"); }
    setBusy(false);
  };
  return (
    <div className="payment-box">
      <div className="msg"><Send size={20} style={{ color: "var(--mint)" }} /><div><div style={{ fontWeight: 600, fontSize: 14.5 }}>Ready to publish</div><p style={{ fontSize: 13 }}>Your campaign is funded. Publish it to the marketplace so creators can apply.</p></div></div>
      <button className="btn btn-primary btn-sm" onClick={publish} disabled={busy}>{busy ? "Publishing…" : "Publish to marketplace"}</button>
      {error && <div className="auth-error" style={{ marginTop: 12, width: "100%" }}>{error}</div>}
    </div>
  );
}

function ApplicationCard({ app, campaign, canAcceptMore, onDecide, onRequestInfo, onCancelAssignment, onReviewProof, onRefresh }) {
  const [showInfoBox, setShowInfoBox] = useState(false);
  const [infoNote, setInfoNote] = useState("");
  const [noteDraft, setNoteDraft] = useState("");
  const [showNoteFor, setShowNoteFor] = useState(null);
  const [messages, setMessages] = useState([]);
  const [msgText, setMsgText] = useState("");
  const [showMsg, setShowMsg] = useState(false);
  const [rating, setRating] = useState(5);
  const [reviewText, setReviewText] = useState("");
  const [reviewSent, setReviewSent] = useState(false);

  const assignment = app.assignment;
  const deliverable = app.deliverable;
  const latestVersion = deliverable?.versions?.[0];

  useEffect(() => {
    if (app.status === "ACCEPTED") api.getMessages(app.id).then((r) => setMessages(r.messages)).catch(() => {});
  }, [app.id, app.status]);

  const submitMessage = async () => {
    if (!msgText.trim()) return;
    const m = await api.sendMessage(app.id, msgText.trim());
    setMessages([...messages, m]);
    setMsgText("");
  };
  const submitReview = async () => { await api.submitReview(app.id, { rating, text: reviewText }); setReviewSent(true); };

  return (
    <div className="app-card">
      <div className="app-card-top">
        <div style={{ display: "flex", gap: 12 }}>
          <div className="avatar" style={{ width: 38, height: 38, fontSize: 13 }}>{initials(app.creatorName)}</div>
          <div>
            <div className="row-title">{app.creatorName}</div>
            <div className="row-sub">proposed {fmt(app.proposedRate)}{app.estimatedCompletionDays ? ` · ~${app.estimatedCompletionDays}d` : ""}</div>
          </div>
        </div>
        {app.status === "PENDING" ? <span className="badge badge-gold">Pending</span> : app.status === "ACCEPTED" ? <span className="badge badge-mint">Accepted</span> : app.status === "WITHDRAWN" ? <span className="badge badge-muted">Withdrawn</span> : <span className="badge badge-red">Rejected</span>}
      </div>
      <div className="app-msg">{app.message}</div>
      {app.relevantExperience && <div className="field-hint" style={{ marginTop: 8 }}>Experience: {app.relevantExperience}</div>}
      {app.infoRequestedAt && <div className="field-hint" style={{ marginTop: 8, color: "var(--gold)" }}>Info requested: {app.infoRequestedNote}</div>}

      {app.status === "PENDING" && (
        <>
          <div className="app-actions">
            <button className="btn btn-sm btn-accept" disabled={!canAcceptMore} onClick={() => onDecide(app.id, "ACCEPTED")}><CheckCircle2 size={14} /> Accept</button>
            <button className="btn btn-sm btn-reject" onClick={() => onDecide(app.id, "REJECTED")}><XCircle size={14} /> Reject</button>
            <button className="btn btn-ghost btn-sm" onClick={() => setShowInfoBox(!showInfoBox)}><Info size={14} /> Request info</button>
          </div>
          {showInfoBox && (
            <div className="field" style={{ marginTop: 10, marginBottom: 0 }}>
              <textarea placeholder="What else do you need to know?" value={infoNote} onChange={(e) => setInfoNote(e.target.value)} />
              <button className="btn btn-primary btn-sm" style={{ marginTop: 8 }} onClick={() => { onRequestInfo(app.id, infoNote); setShowInfoBox(false); setInfoNote(""); }}>Send request</button>
            </div>
          )}
          {!canAcceptMore && <div className="field-hint" style={{ marginTop: 8 }}>All creator slots are filled.</div>}
        </>
      )}

      {app.status === "ACCEPTED" && assignment && (
        <>
          {assignment.status === "ACTIVE" && !deliverable && (
            <button className="btn btn-ghost btn-sm" style={{ marginTop: 12 }} onClick={() => onCancelAssignment(assignment.id)}><Ban size={14} /> Cancel acceptance</button>
          )}
          <div className="review-block" style={{ marginTop: 14 }}>
            <h4>Deliverable {deliverable ? `(v${deliverable.currentVersion})` : ""}</h4>
            {!deliverable ? (
              <div className="val dim">Awaiting the creator to submit work.</div>
            ) : (
              <>
                <div style={{ marginBottom: 8 }}><span className="badge badge-muted">{deliverable.status.replace("_", " ")}</span></div>
                {latestVersion?.contentUrl && <div className="val dim" style={{ wordBreak: "break-all", marginBottom: 4 }}>Content: {latestVersion.contentUrl}</div>}
                {latestVersion?.promotionUrl && <div className="val dim" style={{ wordBreak: "break-all", marginBottom: 4 }}>Promotion: {latestVersion.promotionUrl}</div>}
                {latestVersion?.notes && <div className="val dim" style={{ marginBottom: 4 }}>{latestVersion.notes}</div>}
                {deliverable.reviewNote && <div className="field-hint" style={{ marginTop: 6 }}>Your note: {deliverable.reviewNote}</div>}
                {deliverable.versions.length > 1 && <div className="field-hint" style={{ marginTop: 6 }}>{deliverable.versions.length} versions submitted (history kept).</div>}

                {["SUBMITTED", "UNDER_REVIEW"].includes(deliverable.status) && (
                  <div className="app-actions">
                    {deliverable.status === "SUBMITTED" && <button className="btn btn-ghost btn-sm" onClick={() => onReviewProof(assignment.id, "start_review").then(onRefresh)}><Eye size={14} /> Start review</button>}
                    <button className="btn btn-sm btn-accept" onClick={() => onReviewProof(assignment.id, "approve").then(onRefresh)}><CheckCircle2 size={14} /> Approve &amp; pay</button>
                    <button className="btn btn-ghost btn-sm" onClick={() => setShowNoteFor(showNoteFor === "revision" ? null : "revision")}><AlertCircle size={14} /> Request revision</button>
                    <button className="btn btn-ghost btn-sm" onClick={() => setShowNoteFor(showNoteFor === "reject" ? null : "reject")}><XCircle size={14} /> Reject</button>
                    <button className="btn btn-reject btn-sm" onClick={() => setShowNoteFor(showNoteFor === "dispute" ? null : "dispute")}><Flag size={14} /> Dispute</button>
                  </div>
                )}
                {showNoteFor && (
                  <div className="field" style={{ marginTop: 10, marginBottom: 0 }}>
                    <textarea placeholder="Note..." value={noteDraft} onChange={(e) => setNoteDraft(e.target.value)} />
                    <button className="btn btn-primary btn-sm" style={{ marginTop: 8 }} onClick={() => { onReviewProof(assignment.id, showNoteFor, noteDraft).then(onRefresh); setShowNoteFor(null); setNoteDraft(""); }}>Submit</button>
                  </div>
                )}
              </>
            )}
          </div>

          {deliverable && deliverable.status === "APPROVED" && !reviewSent && (
            <div className="review-block">
              <h4>Rate this creator</h4>
              <div style={{ display: "flex", gap: 4, marginBottom: 10 }}>
                {[1, 2, 3, 4, 5].map((n) => <button key={n} onClick={() => setRating(n)} style={{ background: "none", border: "none", padding: 0 }}><Star size={20} fill={n <= rating ? "var(--gold)" : "none"} style={{ color: "var(--gold)" }} /></button>)}
              </div>
              <div className="field" style={{ marginBottom: 8 }}><textarea value={reviewText} onChange={(e) => setReviewText(e.target.value)} /></div>
              <button className="btn btn-primary btn-sm" onClick={submitReview}>Submit review</button>
            </div>
          )}
          {deliverable && deliverable.status === "APPROVED" && reviewSent && <div className="field-hint" style={{ marginLeft: 2 }}>✓ Review submitted.</div>}

          <div className="review-block">
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", cursor: "pointer" }} onClick={() => setShowMsg(!showMsg)}>
              <h4 style={{ marginBottom: 0 }}>Messages ({messages.length})</h4><MessageSquare size={15} style={{ color: "var(--text-faint)" }} />
            </div>
            {showMsg && (
              <>
                <div style={{ maxHeight: 220, overflowY: "auto", marginTop: 12 }}>
                  {messages.map((m) => <div key={m.id} style={{ marginBottom: 10 }}><div style={{ display: "inline-block", background: "var(--surface-2)", padding: "8px 12px", borderRadius: 10, fontSize: 13 }}>{m.text}</div></div>)}
                </div>
                <div className="field" style={{ display: "flex", gap: 8, marginTop: 10, marginBottom: 0 }}>
                  <input type="text" value={msgText} onChange={(e) => setMsgText(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") submitMessage(); }} />
                  <button className="btn btn-primary btn-sm" onClick={submitMessage}>Send</button>
                </div>
              </>
            )}
          </div>
        </>
      )}
    </div>
  );
}

function CampaignDetail({ campaignId, onBack }) {
  const [campaign, setCampaign] = useState(null);
  const [applications, setApplications] = useState([]);
  const [history, setHistory] = useState([]);
  const [tab, setTab] = useState("overview");
  const [loading, setLoading] = useState(true);

  const load = async () => {
    const [c, a, h] = await Promise.all([api.getCampaign(campaignId), api.campaignApplications(campaignId), api.getCampaignHistory(campaignId)]);
    setCampaign(c.campaign); setApplications(a.applications); setHistory(h.history);
    setLoading(false);
  };
  useEffect(() => { load(); }, [campaignId]);

  if (loading || !campaign) return <div className="empty">Loading campaign…</div>;

  const Icon = PLATFORM_ICONS[campaign.platform];
  const acceptedCount = applications.filter((a) => a.assignment?.status === "ACTIVE").length;
  const canAcceptMore = acceptedCount < campaign.maxCreators;

  const decide = async (appId, decision) => { await api.decideApplication(appId, decision); load(); };
  const requestInfo = async (appId, note) => { await api.requestApplicationInfo(appId, note); load(); };
  const cancelAssignment = async (assignmentId) => { await api.cancelAssignment(assignmentId); load(); };
  const reviewProof = (assignmentId, decision, note) => api.reviewDeliverable(assignmentId, decision, note);

  return (
    <div>
      <button className="back-link" onClick={onBack}><ChevronLeft size={15} /> Back to campaigns</button>
      <div className="cm-head">
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6, flexWrap: "wrap" }}>
            <h2>{campaign.title}</h2>
            <StatusBadge status={campaign.status} />
          </div>
          <div className="camp-card-meta"><Icon size={14} style={{ color: PLATFORM_COLORS[campaign.platform] }} /> {PLATFORM_LABELS[campaign.platform]} · {campaign.category}</div>
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          {["DRAFT"].includes(campaign.status) && <button className="btn btn-ghost btn-sm" onClick={() => onBack("edit")}>Edit</button>}
          {["DRAFT", "PENDING_PAYMENT", "FUNDED", "PUBLISHED", "IN_PROGRESS", "SUBMITTED", "UNDER_REVIEW", "DISPUTED"].includes(campaign.status) && (
            <button className="btn btn-ghost btn-sm" onClick={async () => { await api.cancelCampaign(campaign.id); load(); }}>Cancel campaign</button>
          )}
          {["IN_PROGRESS", "SUBMITTED", "UNDER_REVIEW"].includes(campaign.status) && (
            <button className="btn btn-primary btn-sm" onClick={async () => { await api.completeCampaign(campaign.id); load(); }}>Mark completed</button>
          )}
        </div>
      </div>

      {NEXT_STEP[campaign.status] && (
        <div className="divider-note" style={{ marginBottom: 14, display: "flex", gap: 8, alignItems: "center" }}>
          <Info size={14} /> <span><strong>Next step:</strong> {NEXT_STEP[campaign.status]}</span>
        </div>
      )}
      {campaign.status === "PENDING_PAYMENT" && <PaymentBox campaign={campaign} onFunded={load} />}
      {campaign.status === "FUNDED" && <PublishBox campaign={campaign} onPublished={load} />}

      <div className="tabs-row">
        <button className={`tab-btn ${tab === "overview" ? "active" : ""}`} onClick={() => setTab("overview")}>Overview</button>
        <button className={`tab-btn ${tab === "applications" ? "active" : ""}`} onClick={() => setTab("applications")}>Applications ({applications.length})</button>
        <button className={`tab-btn ${tab === "timeline" ? "active" : ""}`} onClick={() => setTab("timeline")}>Activity timeline</button>
      </div>

      {tab === "overview" && (
        <div className="two-col">
          <div>
            {campaign.accountName && <div className="review-block"><h4>Channel / page name</h4><div className="val">{campaign.accountName}</div></div>}
            <div className="review-block"><h4>Link</h4><div className="val" style={{ wordBreak: "break-all" }}>{campaign.contentUrl}</div></div>
            {campaign.description && campaign.description !== campaign.requirements && <div className="review-block"><h4>Description</h4><div className="val dim">{campaign.description}</div></div>}
            <div className="review-block"><h4>What the creator should do</h4><div className="val dim">{campaign.requirements}</div>
              {campaign.requirementsList?.length > 0 && <div className="tag-row">{campaign.requirementsList.map((r, i) => <span className="tag" key={i}>{r}</span>)}</div>}
            </div>
            {campaign.eligibilityRequirements && <div className="review-block"><h4>Eligibility</h4><div className="val dim">{campaign.eligibilityRequirements}</div></div>}
          </div>
          <div>
            <div className="review-block">
              <h4>Budget</h4>
              <div className="val mono" style={{ fontSize: 20 }}>{fmt(campaign.budget)}</div>
              <div className="field-hint">{fmt(campaign.budgetPerCreator)} per creator · {campaign.commissionPercent}% platform commission</div>
            </div>
            <div className="review-block">
              <h4>Schedule</h4>
              <div className="val">{fmtDate(campaign.startDate)} → {fmtDate(campaign.endDate)}</div>
              {campaign.targetCountry && <div className="field-hint">Target: {campaign.targetCountry}</div>}
            </div>
            <div className="review-block">
              <h4>Creator slots</h4>
              <div className="val">{acceptedCount} / {campaign.maxCreators} accepted</div>
              <div className="progress-track" style={{ marginTop: 10 }}><div className="progress-fill" style={{ width: `${Math.min(100, Math.round((acceptedCount / campaign.maxCreators) * 100))}%` }} /></div>
            </div>
          </div>
        </div>
      )}

      {tab === "applications" && (
        applications.length === 0 ? <div className="panel"><div className="empty">No applications yet.</div></div> :
          applications.map((a) => <ApplicationCard key={a.id} app={a} campaign={campaign} canAcceptMore={canAcceptMore} onDecide={decide} onRequestInfo={requestInfo} onCancelAssignment={cancelAssignment} onReviewProof={reviewProof} onRefresh={load} />)
      )}

      {tab === "timeline" && (
        <div className="panel"><div className="panel-body">
          {history.map((h) => (
            <div className="row" key={h.id}>
              <div><div className="row-title">{h.from_status ? `${h.from_status} → ${h.to_status}` : `Created as ${h.to_status}`}</div><div className="row-sub">{h.note || ""}</div></div>
              <span style={{ fontSize: 11.5, color: "var(--text-faint)" }}>{new Date(h.created_at).toLocaleString()}</span>
            </div>
          ))}
        </div></div>
      )}
    </div>
  );
}

function CampaignCard({ campaign, onClick }) {
  const Icon = PLATFORM_ICONS[campaign.platform];
  return (
    <div className="camp-card" onClick={onClick}>
      <div className="camp-card-top">
        <div>
          <div className="camp-card-name">{campaign.title}</div>
          <div className="camp-card-meta"><Icon size={14} style={{ color: PLATFORM_COLORS[campaign.platform] }} /> {PLATFORM_LABELS[campaign.platform]} · {campaign.category}</div>
        </div>
        <StatusBadge status={campaign.status} />
      </div>
      <div className="camp-stats-row">
        <div className="camp-stat"><div className="v mono">{fmt(campaign.budget)}</div><div className="l">Budget</div></div>
        <div className="camp-stat"><div className="v">{campaign.acceptedCount || 0}/{campaign.maxCreators}</div><div className="l">Creators</div></div>
        <div className="camp-stat"><div className="v">{campaign.applicantCount || 0}</div><div className="l">Applicants</div></div>
        <div className="camp-stat"><div className="v">{fmtDate(campaign.endDate)}</div><div className="l">Deadline</div></div>
      </div>
    </div>
  );
}

function CampaignsModule() {
  const [campaigns, setCampaigns] = useState([]);
  const [view, setView] = useState("list");
  const [selectedId, setSelectedId] = useState(null);
  const [editingCampaign, setEditingCampaign] = useState(null);
  const [statusFilter, setStatusFilter] = useState("All");
  const [loading, setLoading] = useState(true);

  const load = async () => { const r = await api.myCampaigns(); setCampaigns(r.campaigns); setLoading(false); };
  useEffect(() => { load(); }, []);

  if (view === "new") return <CampaignForm onCancel={() => setView("list")} onSaved={() => { setView("list"); load(); }} />;
  if (view === "edit") return <CampaignForm existing={editingCampaign} onCancel={() => setView("list")} onSaved={() => { setView("list"); load(); }} />;
  if (view === "detail") return <CampaignDetail campaignId={selectedId} onBack={(next) => {
    if (next === "edit") { setEditingCampaign(campaigns.find((c) => c.id === selectedId)); setView("edit"); }
    else { setView("list"); load(); }
  }} />;

  const filtered = statusFilter === "All" ? campaigns : campaigns.filter((c) => c.status === statusFilter);
  const statuses = ["All", "DRAFT", "PENDING_PAYMENT", "FUNDED", "PUBLISHED", "IN_PROGRESS", "SUBMITTED", "UNDER_REVIEW", "COMPLETED", "CANCELLED", "DISPUTED"];

  return (
    <>
      <div className="chip-row" style={{ marginBottom: 16 }}>
        {statuses.map((s) => <div key={s} className={`filter-chip ${statusFilter === s ? "active" : ""}`} style={{ cursor: "pointer" }} onClick={() => setStatusFilter(s)}>{s === "All" ? "All" : s.replaceAll("_", " ")}</div>)}
      </div>
      <div className="cm-head">
        <div className="results-count" style={{ marginBottom: 0 }}>{filtered.length} campaign{filtered.length !== 1 ? "s" : ""}</div>
        <button className="btn btn-primary btn-sm" onClick={() => setView("new")}><Plus size={14} /> New campaign</button>
      </div>
      {loading ? <div className="empty">Loading…</div> : filtered.length === 0 ? (
        <div className="panel"><div className="empty">No campaigns match.<div style={{ marginTop: 14 }}><button className="btn btn-primary btn-sm" onClick={() => setView("new")}>Create your first campaign</button></div></div></div>
      ) : (
        filtered.map((c) => <CampaignCard key={c.id} campaign={c} onClick={() => { setSelectedId(c.id); setView("detail"); }} />)
      )}
    </>
  );
}

function WalletModule() {
  const [wallet, setWallet] = useState(null);
  const [ledger, setLedger] = useState([]);
  useEffect(() => { api.getWallet().then((r) => { setWallet(r.wallet); setLedger(r.ledger); }); }, []);
  if (!wallet) return <div className="empty">Loading wallet…</div>;
  return (
    <>
      <div className="stat-grid">
        <div className="stat-card"><div className="stat-top"><div className="stat-icon" style={{ background: "var(--coral-dim)" }}><WalletIcon size={16} style={{ color: "var(--coral)" }} /></div></div><div className="stat-val">{fmt(wallet.balance)}</div><div className="stat-lbl">Available balance</div></div>
        <div className="stat-card"><div className="stat-top"><div className="stat-icon" style={{ background: "var(--mint-dim)" }}><TrendingUp size={16} style={{ color: "var(--mint)" }} /></div></div><div className="stat-val">{fmt(wallet.totalEarned)}</div><div className="stat-lbl">Total credited</div></div>
      </div>
      <div className="panel">
        <div className="panel-head"><h3>Ledger</h3></div>
        <div className="panel-body">
          {ledger.length === 0 ? <div className="empty">No wallet activity yet. An admin can credit your wallet (a stand-in for a real payment top-up — see README) so you can fund campaigns.</div> : ledger.map((l) => (
            <div className="row" key={l.id}>
              <div><div className="row-title">{l.reason.replaceAll("_", " ")}</div><div className="row-sub">{new Date(l.createdAt).toLocaleString()}</div></div>
              <div className="mono" style={{ color: l.direction === "CREDIT" ? "var(--mint)" : "var(--text-dim)" }}>{l.direction === "CREDIT" ? "+" : "-"}{fmt(l.amount)}</div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

export default function AdvertiserDashboard({ tab }) {
  if (tab === "wallet") return <WalletModule />;
  return <CampaignsModule />;
}
